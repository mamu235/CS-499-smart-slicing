---
layout: post
title: "Mitch - Website Launched"
date: 2018-02-05
---

Mitch Launched the GitHub Pages site. Having Trouble separating the Project Log into 3 separate Sections for each Tem Members Individual Posts. Will be tackling this Issue Next Week.
