---
layout: post
title: "Chris Guallpa - Week 2 Find resources and Establish Project Direction"
date: 2018-02-18
---

 This week we figured out what method we wanted to approach the problem in. Our current solutions are a plug in into the slicer Cura that will create variable z slicing on layers and extrusions. This beat out the implementation of a program that would take the g-code and alter it directly. currently we are testing [this plug in](https://github.com/ChrisTerBeke/CuraVariSlicePlugin) found in github by the creators of varislice that can be used with cura. We currently need to see what kind of support it currently has and how it is implemented along with Cura. We also need to discuss project direction if this plug in takes care of most of the project requirements and how Dr. Dietz would like us to further expand on the project. We will have planned on a day to be set for testing, with each of us individually installing the plug-in into our machine to test with and also a day next week that will be to meet with Dr. Dietz and further establish project expectations. This week was also set on getting familiar with another of the maker space labs and understanding [Varislice](http://www.instructables.com/id/Variable-Slicing-for-3D-Printing-on-Autodesk-Ember/) coding and methology.
 
