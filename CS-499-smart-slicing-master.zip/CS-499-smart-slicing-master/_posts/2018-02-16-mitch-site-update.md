---
layout: post
title: Mitch - Update on Website
---
<p>This Week I have updated the Team Website to have 3 individual Project Logs, as well as having updated the About Page, and the Project Requirements page. 
Also, I have added a Project Timeline Page to our Website, with a Google Calendar Widget.
</p>
