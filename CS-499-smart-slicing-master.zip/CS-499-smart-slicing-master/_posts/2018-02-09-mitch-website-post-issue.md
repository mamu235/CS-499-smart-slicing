---
layout: post
title: Mitch - Issues with Website Project Log
---
<p>I am having issues being able to split our Project Log into 3 separate logs, 1 for each Team Member. I have emailed Dr. Piwowarski about the issue and am awaiting a Response. We have also added a Requirements Section to the Website, per Website Requirements</p>
