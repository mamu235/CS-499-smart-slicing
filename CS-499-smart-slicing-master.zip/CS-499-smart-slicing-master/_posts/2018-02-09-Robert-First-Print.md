---
layout: post
title: "Robert Williams - First Print"
date: 2018--02--09
---
<p>
This week the primary goal was to print off the 3D tag neccessary to print in the makers lab in RGAN, and to research the topic.The tag has been created, and a deeper understanding of how to use a 3D printer. This is a big step for me personally as I have never used a 3D printer. I am currently researching for reliable sources that can help us start this project.
</p>