# CS-499-smart-slicing README

## Adding New Posts

In order to add a new post to report what you've done this week, go to the 
```_posts```
Directory and in the upper left select 
```Make New File```

##You need to name this file very precisely!

the post name needs to be named according to the following scheme:
```YYYY-MM-DD-title-of-my-post.md```

Then follow this Template:
```
---
layout: post
title: "YOUR NAME - TITLE OF POST"
date: YYYY-MM-DD
---

<CONTENT CONTENT CONTENT>```

Make sure to put your name in the Title of the Post!!!
